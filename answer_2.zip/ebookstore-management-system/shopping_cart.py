class ShoppingCart:
    def __init__(self):
        """Initialize ShoppingCart with an empty list of order items."""
        self.__items = []

    def add_item(self, item: 'OrderItem'):
        self.__items.append(item)

    def remove_item(self, item: 'OrderItem'):
        self.__items.remove(item)

    def get_items(self):
        return self.__items

    def __str__(self):
        item_details = "\n".join([str(item) for item in self.__items])
        return f"ShoppingCart(items=\n{item_details})"
