class Order:
    VAT_RATE = 0.08  # 8% VAT

    def __init__(self, customer: 'Customer', items: list, discount: float = 0):
        """Initialize Order with customer, items, and discount."""
        self.__customer = customer
        self.__items = items
        self.__discount = discount

    def get_total_price(self):
        total = sum(item.get_total_price() for item in self.__items)
        total_after_discount = total * (1 - self.__discount)
        return total_after_discount * (1 + self.VAT_RATE)

    def __str__(self):
        item_details = "\n".join([str(item) for item in self.__items])
        return (f"Order(customer={self.__customer.get_name()}, total_price={self.get_total_price()}, items=\n{item_details})")
