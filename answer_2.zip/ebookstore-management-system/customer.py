class Customer:
    def __init__(self, name: str, contact_info: str, loyalty_member: bool = False):
        """Initialize Customer with name, contact info, and loyalty membership status."""
        self.__name = name
        self.__contact_info = contact_info
        self.__loyalty_member = loyalty_member

    # Getters
    def get_name(self):
        return self.__name

    def get_contact_info(self):
        return self.__contact_info

    def is_loyalty_member(self):
        return self.__loyalty_member

    # Setters
    def set_contact_info(self, contact_info: str):
        self.__contact_info = contact_info

    def set_loyalty_member(self, loyalty_member: bool):
        self.__loyalty_member = loyalty_member

    def __str__(self):
        return f"Customer(name={self.__name}, loyalty_member={self.__loyalty_member})"
