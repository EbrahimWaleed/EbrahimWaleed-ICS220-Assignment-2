class OrderItem:
    def __init__(self, ebook: 'Ebook', quantity: int):
        """Initialize OrderItem with ebook and quantity."""
        self.__ebook = ebook
        self.__quantity = quantity

    # Getters
    def get_ebook(self):
        return self.__ebook

    def get_quantity(self):
        return self.__quantity

    # Setters
    def set_quantity(self, quantity: int):
        self.__quantity = quantity

    def get_total_price(self):
        return self.__ebook.get_price() * self.__quantity

    def __str__(self):
        return f"OrderItem(ebook={self.__ebook.get_title()}, quantity={self.__quantity}, total_price={self.get_total_price()})"
