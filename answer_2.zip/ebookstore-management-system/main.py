import unittest
from ebook import Ebook
from customer import Customer
from order_item import OrderItem
from order import Order
from shopping_cart import ShoppingCart
from discount import Discount


class TestEbook(unittest.TestCase):
    def test_initialization(self):
        # Test initializing an Ebook object and checking its title and price.
        ebook = Ebook("Book Title", "Author Name", "2023-01-01", "Fiction", 29.99)
        self.assertEqual(ebook.get_title(), "Book Title")
        self.assertEqual(ebook.get_price(), 29.99)

    def test_set_price(self):
        # Test updating the price of an Ebook and verifying the updated value.
        ebook = Ebook("Book Title", "Author Name", "2023-01-01", "Fiction", 29.99)
        ebook.set_price(34.99)
        self.assertEqual(ebook.get_price(), 34.99)


class TestCustomer(unittest.TestCase):
    def test_initialization(self):
        # Test initializing a Customer with loyalty status and checking name.
        customer = Customer("Alice", "alice@example.com", True)
        self.assertTrue(customer.is_loyalty_member())
        self.assertEqual(customer.get_name(), "Alice")

    def test_set_contact_info(self):
        # Test updating a customer's contact information.
        customer = Customer("Alice", "alice@example.com", True)
        customer.set_contact_info("newemail@example.com")
        self.assertEqual(customer.get_contact_info(), "newemail@example.com")


class TestOrderItem(unittest.TestCase):
    def test_order_item_total_price(self):
        # Test calculating the total price for an order item based on quantity.
        ebook = Ebook("Book Title", "Author Name", "2023-01-01", "Fiction", 10.0)
        order_item = OrderItem(ebook, 3)
        self.assertEqual(order_item.get_total_price(), 30.0)  # 3 * 10.0

    def test_set_quantity(self):
        # Test updating the quantity of an order item and verifying the quantity.
        ebook = Ebook("Book Title", "Author Name", "2023-01-01", "Fiction", 10.0)
        order_item = OrderItem(ebook, 3)
        order_item.set_quantity(5)
        self.assertEqual(order_item.get_quantity(), 5)


class TestOrder(unittest.TestCase):
    def test_order_total_price_with_discount_and_vat(self):
        # Test calculating total price for an order with a loyalty discount and VAT.
        customer = Customer("Bob", "bob@example.com", True)
        ebook1 = Ebook("Ebook One", "Author A", "2022-01-01", "Fiction", 15.0)
        ebook2 = Ebook("Ebook Two", "Author B", "2021-05-05", "Non-fiction", 20.0)
        order_item1 = OrderItem(ebook1, 2)
        order_item2 = OrderItem(ebook2, 1)
        order = Order(customer, [order_item1, order_item2], discount=0.1)  # 10% discount
        self.assertAlmostEqual(order.get_total_price(), (50 * 0.9) * 1.08)  # Total with discount and VAT

    def test_order_without_items(self):
        # Test an order with no items to ensure the total price is zero.
        customer = Customer("Bob", "bob@example.com", True)
        order = Order(customer, [], discount=0)
        self.assertEqual(order.get_total_price(), 0)


class TestShoppingCart(unittest.TestCase):
    def test_add_and_remove_item(self):
        # Test adding and removing an item from the shopping cart.
        ebook = Ebook("Sample Book", "Author Name", "2023-01-01", "Fiction", 15.0)
        order_item = OrderItem(ebook, 1)
        cart = ShoppingCart()
        cart.add_item(order_item)
        self.assertIn(order_item, cart.get_items())  # Check if item is added

        cart.remove_item(order_item)
        self.assertNotIn(order_item, cart.get_items())  # Check if item is removed

    def test_empty_cart(self):
        # Test that a new cart is initially empty.
        cart = ShoppingCart()
        self.assertEqual(len(cart.get_items()), 0)


class TestDiscount(unittest.TestCase):
    def test_loyalty_discount(self):
        # Test applying a loyalty discount based on customer's loyalty status.
        discount = Discount(loyalty_discount=0.1, bulk_discount=0.2)
        self.assertEqual(discount.apply_loyalty_discount(True), 0.1)  # Loyalty member
        self.assertEqual(discount.apply_loyalty_discount(False), 0)  # Non-member

    def test_bulk_discount(self):
        # Test applying bulk discount for orders with 5 or more e-books.
        discount = Discount(loyalty_discount=0.1, bulk_discount=0.2)
        self.assertEqual(discount.apply_bulk_discount(5), 0.2)  # 5 or more e-books
        self.assertEqual(discount.apply_bulk_discount(4), 0)  # Less than 5 e-books, no discount


if __name__ == "__main__":
    unittest.main()
