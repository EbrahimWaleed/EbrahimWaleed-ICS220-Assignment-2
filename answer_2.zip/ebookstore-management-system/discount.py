class Discount:
    def __init__(self, loyalty_discount: float = 0.1, bulk_discount: float = 0.2):
        """Initialize Discount with loyalty and bulk discount rates."""
        self.__loyalty_discount = loyalty_discount
        self.__bulk_discount = bulk_discount

    def apply_loyalty_discount(self, is_member: bool):
        return self.__loyalty_discount if is_member else 0

    def apply_bulk_discount(self, quantity: int):
        return self.__bulk_discount if quantity >= 5 else 0

    def __str__(self):
        return f"Discount(loyalty_discount={self.__loyalty_discount}, bulk_discount={self.__bulk_discount})"
