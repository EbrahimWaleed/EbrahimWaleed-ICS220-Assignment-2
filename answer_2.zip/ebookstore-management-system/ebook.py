class Ebook:
    def __init__(self, title: str, author: str, publication_date: str, genre: str, price: float):
        """Initialize Ebook with title, author, publication date, genre, and price."""
        self.__title = title
        self.__author = author
        self.__publication_date = publication_date
        self.__genre = genre
        self.__price = price

    # Getters
    def get_title(self):
        return self.__title

    def get_author(self):
        return self.__author

    def get_publication_date(self):
        return self.__publication_date

    def get_genre(self):
        return self.__genre

    def get_price(self):
        return self.__price

    # Setters
    def set_price(self, price: float):
        self.__price = price

    def __str__(self):
        return f"Ebook(title={self.__title}, author={self.__author}, price={self.__price})"
